--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7 (Ubuntu 10.7-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 11.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: jcm_access_type; Type: TABLE DATA; Schema: public; Owner: amiesca
--


--
-- Data for Name: jcm_role; Type: TABLE DATA; Schema: public; Owner: amiesca
--


--
-- Data for Name: jcm_user; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_user (id, mail_address, salt, password, username, token, ts_access, fk_user_role) FROM stdin;
2	amisimple@amiescalade.fr	salt	$2a$12$nepuWlobO3L6URV5ebgSxOaxowWrGp5FJTU5unYly91rbyDzLxBOe	amisimple		2019-11-03 13:08:09.769	2
3	amimembre@amiescalade.fr	salt	$2a$12$t1N02eQd0uCUeGW4.v7xoOqMk2OCZO0h.V5JH4CG7P8/CmAjPtT0.	amimembre		2019-11-03 13:08:10.6	3
4	julien.lami@amiescalade.fr	salt	$2a$12$NM.RBQ9e.U3S.7jTlh/fue4aMxTZbvr4UqWXMBBdMKIfwrZHFg0fK	lamijiii		2019-11-03 13:08:11.273	4
5	christine.chappard@amiescalade.fr	salt	$2a$12$f6SLaqQa0ihPNE8dvEwJ4eYho2i.P6LoIDnypXCt7uOWUGNEJbq/.	chachristi		2019-11-03 13:08:11.923	2
6	solene.marsault@amiescalade.fr	salt	$2a$12$jzBJ2W1oNW2R9SMSDlog5OS721pSFEQ8pUR13Vy6io5QYQM7THVzy	solemarsa		2019-11-03 13:08:12.56	2
\.


--
-- Data for Name: jcm_reference; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_reference (id, name, type, summary, slug, fk_document_user, ts_created, ts_modified, published, content) FROM stdin;
1	Autoire	SITE	Lorem ipsum dolor sit amet, consectetur	autoire	3	2019-11-03 13:08:12.676	2019-11-03 13:08:12.676	t	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostru
2	Cantobre	SITE	labore et dolore magna aliqua. Ut enimad minim	cantobre	4	2019-11-03 13:08:12.723	2019-11-03 13:08:12.724	t	labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupi
3	Kerlouan	SITE	doeiusmod tempor incididunt ut labore	kerlouan	3	2019-11-03 13:08:12.76	2019-11-03 13:08:12.76	t	doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ull
4	Les Gorges du Loup	SITE	adipisicing elit, sed doeiusmod tempor	les_gorges_du_loup	3	2019-11-03 13:08:12.791	2019-11-03 13:08:12.791	t	adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nu
5	Annot	SITE	sed doeiusmod tempor	annot	4	2019-11-03 13:08:12.824	2019-11-03 13:08:12.824	t	sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostru
6	Bionnassay	SITE	Excepteur sint occaecat cupidatat non	bionnassay	6	2019-11-03 13:08:12.857	2019-11-03 13:08:12.857	t	Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore
7	Castillon	SITE	labore et dolore magna aliqua. Ut enimad	castillon	5	2019-11-03 13:08:12.892	2019-11-03 13:08:12.892	t	labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupi
8	Claret	SITE	doeiusmod tempor incididunt ut labore	claret	5	2019-11-03 13:08:12.923	2019-11-03 13:08:12.923	t	doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ull
11	La Combe obscure	SITE	sed doeiusmod tempor incididunt ut labore	la_combe_obscure	5	2019-11-03 13:08:13.04	2019-11-03 13:08:13.04	t	sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consecte
14	La hottee du diable	SITE	amet, consectetur adipisicing elit	la_hottee_du_diable	4	2019-11-03 13:08:13.11	2019-11-03 13:08:13.11	t	amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna al
16	La Turbie	SITE	sed doeiusmod tempor incididunt ut	la_turbie	2	2019-11-03 13:08:13.164	2019-11-03 13:08:13.164	t	sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostru
17	Le Caroux	SITE	Excepteur sint occaecat cupidatat	le_caroux	6	2019-11-03 13:08:13.188	2019-11-03 13:08:13.188	t	Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore
18	Medonnet	SITE	magna aliqua. Ut enimad minim	medonnet	5	2019-11-03 13:08:13.222	2019-11-03 13:08:13.222	f	magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor 
19	Grimpe en auvergne	TOPO	exercitation ullamco laboris nisi utaliquip ex ea commodo	grimpe_en_auvergne	1	2019-11-03 13:08:13.304	2019-11-03 13:08:13.304	t	\N
20	Tout l aveyron	TOPO	dolore magna aliqua. Ut enimad minim veniam, quis	tout_l_aveyron	5	2019-11-03 13:08:13.362	2019-11-03 13:08:13.362	t	\N
21	Falaises de Marne	TOPO	incididunt ut labore et dolore magna aliqua	falaises_de_marne	2	2019-11-03 13:08:13.414	2019-11-03 13:08:13.414	t	\N
13	La falaise de Cohons	SITE	elit, sed doeiusmod tempor	la_falaise_de_cohons	4	2019-11-03 13:08:13.085	2019-11-03 13:09:17.655	t	elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo consequat. Duis aute irure dolor inreprehenderit in voluptate velit esse cillum dolore eu fugiat nullapariatur. Excepteur sint occaecat cupidatat non proident, sunt inculpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, s
\.


--
-- Data for Name: jcm_comment; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_comment (id, ts_created, ts_modified, content, fk_comment_reference, fk_comment_user) FROM stdin;
1	2019-11-03 13:08:13.456	2019-11-03 13:08:13.456	sed doeiusmod tempor incididunt ut labore et	4	3
2	2019-11-03 13:08:13.481	2019-11-03 13:08:13.481	Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo	4	2
3	2019-11-03 13:08:13.504	2019-11-03 13:08:13.504	incididunt ut labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation	4	3
4	2019-11-03 13:08:13.525	2019-11-03 13:08:13.525	labore et dolore magna aliqua. Ut enimad minim veniam, quis nostrud exercitation ullamco laboris	4	2
5	2019-11-03 13:08:13.548	2019-11-03 13:08:13.548	mollit anim id est laborum. Lorem ipsum dolor	4	3
6	2019-11-03 13:08:13.57	2019-11-03 13:08:13.57	enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip	4	2
7	2019-11-03 13:08:13.593	2019-11-03 13:08:13.593	Ut enimad minim veniam, quis nostrud exercitation ullamco laboris	2	4
8	2019-11-03 13:08:13.615	2019-11-03 13:08:13.615	enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip	2	5
9	2019-11-03 13:08:13.636	2019-11-03 13:08:13.636	mollit anim id est laborum. Lorem ipsum dolor	2	4
10	2019-11-03 13:08:13.659	2019-11-03 13:08:13.659	enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip	2	5
11	2019-11-03 13:08:13.68	2019-11-03 13:08:13.68	incididunt ut labore et dolore magna aliqua	2	4
12	2019-11-03 13:08:13.724	2019-11-03 13:08:13.724	Ut enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip ex ea commodo	3	2
13	2019-11-03 13:08:13.748	2019-11-03 13:08:13.748	quis nostrud exercitation ullamco laboris ?	3	6
14	2019-11-03 13:08:13.769	2019-11-03 13:08:13.769	enimad minim veniam, quis nostrud exercitation ullamco laboris nisi utaliquip	3	2
15	2019-11-03 13:08:13.791	2019-11-03 13:08:13.791	mollit anim id est laborum. Lorem ipsum dolor	3	6
\.


--
-- Data for Name: jcm_cotation; Type: TABLE DATA; Schema: public; Owner: amiesca
--


--
-- Data for Name: jcm_message; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_message (id, fk_sender_user, fk_receiver_user, title, content, dt_created, dt_read, parent_id, discussion_id, discussion_masked, last_discussion_message) FROM stdin;
1	2	3	Demande de prêt du topo Grimpe en Auvergne	Bonjour, il a l'air bien ce topo. Peux tu me le prêter s'il te plait	2019-11-03 13:08:13.816	\N	\N	1	0	f
2	3	2	Demande de prêt du topo Grimpe en Auvergne	Pas de soucis, comme tu as vu, il est dispo ;-). Par contre j'en aurai besoin dans une vingtaine de jours...	2019-11-03 13:08:13.835	\N	1	1	0	f
3	2	3	Demande de prêt du topo Grimpe en Auvergne	Ok, je le consulterai sans attendre.	2019-11-03 13:08:13.857	\N	2	1	0	f
5	2	3	Demande de prêt du topo Grimpe en Auvergne	Merci	2019-11-03 13:08:13.904	\N	4	1	0	t
4	3	2	Demande de prêt du topo Grimpe en Auvergne	Donc on fait comme ça	2019-11-03 13:08:13.88	\N	3	1	0	f
6	5	2	Demande de prêt du topo Falaise de marne	Bonjour, il est bien diponible ton topo?	2019-11-03 13:08:13.935	\N	\N	6	0	f
7	2	5	Demande de prêt du topo Falaise de marne	Bonjour. Eh non... Je plaisante. En effet il est dispo.	2019-11-03 13:08:13.957	\N	6	6	0	f
8	5	2	Demande de prêt du topo Falaise de marne	Est ce que tu peux me le prêter s'il te plait? Je vais faire un séjour en Haute-Marne, donc j'aimerais préparer le terrain.	2019-11-03 13:08:13.979	\N	7	6	0	f
10	5	2	Demande de prêt du topo Falaise de marne	oui, ça serait cool :-)	2019-11-03 13:08:14.023	\N	9	6	0	t
9	2	5	Demande de prêt du topo Falaise de marne	Est ce que ça te va, si je te le prête à partir de la fin de semaine?	2019-11-03 13:08:14.001	\N	8	6	0	f
\.


--
-- Data for Name: jcm_site; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_site (pfk_site_reference, country, department, cliff, block, wall, paths_number, min_height, max_height, fk_min_site_cotation, fk_max_site_cotation, orientation, friend_tag) FROM stdin;
1	France	Lot	t	f	f	271	5	25	5	22	Est Sud-Est	f
2	France	Aveyron	t	f	f	55	20	40	7	26	Sud Sud-Est Est	f
3	France	Finistere	f	t	f	1000	1	10	3	20	Toutes	f
4	France	Alpes Maritimes	t	f	f	70	1	45	8	26	Ouest	f
5	France	Alpes de Haute Provence	t	t	f	400	5	25	7	25	toutes	f
6	France	Haute-Savoie	t	f	f	50	5	40	7	26	Ouest - Sud Ouest	f
7	France	Alpes maritimes	t	f	f	55	5	40	10	25	Sud Ouest	f
8	France	Herault	t	t	f	100	5	30	7	24	Sud	f
11	France	Vaucluse	t	f	f	55	5	40	10	25	Sud Ouest	f
13	France	Haute Marne	t	f	f	100	3	8	3	20	Toutes	f
14	France	Marne	f	t	f	55	5	40	3	20	Sud Ouest	f
16	France	Auvergne	t	f	f	400	5	120	4	24	Toutes	f
17	France	Herault	t	f	f	400	5	350	3	18	Toutes	f
18	France	Haute-Savoie	f	t	f	250	1	5	4	20	Toutes	f
\.


--
-- Data for Name: jcm_topo; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_topo (pfk_topo_reference, title, writer, writed_at, published, available) FROM stdin;
19	Grimpe en auvergne	Benoit Cantalou	30/08/2008	t	t
20	Tout l aveyron	Manouel Desurvi	12/10/2013	t	t
21	Falaises de Marne	Marcel Reblochon	05/03/2018	t	t
\.


--
-- Data for Name: jcm_topo_site; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_topo_site (pfk_topo, pfk_site) FROM stdin;
19	4
20	2
21	5
\.


--
-- Name: jcm_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amiesca
--

SELECT pg_catalog.setval('public.jcm_comment_id_seq', 15, true);


--
-- Name: jcm_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amiesca
--

SELECT pg_catalog.setval('public.jcm_message_id_seq', 10, true);


--
-- Name: jcm_reference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amiesca
--

SELECT pg_catalog.setval('public.jcm_reference_id_seq', 21, true);


--
-- Name: jcm_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amiesca
--

SELECT pg_catalog.setval('public.jcm_user_id_seq', 6, true);


--
-- PostgreSQL database dump complete
--

