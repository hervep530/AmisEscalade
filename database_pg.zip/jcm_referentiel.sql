--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7 (Ubuntu 10.7-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 11.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: jcm_access_type; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_access_type (id, name, description) FROM stdin;
1	NONE	can not access
2	READER	can only read
3	AUTHOR	can read, create and modify his own entity
4	EDITOR	can read, create and modify all entities, but not delete
5	MANAGER	full access
\.


--
-- Data for Name: jcm_role; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_role (id, name, fk_site_access, fk_topo_access, fk_comment_access, fk_media_access, fk_user_access, fk_booking_access, fk_message_access) FROM stdin;
1	ANONYMOUS	2	2	2	2	1	1	1
2	USER	3	3	3	3	3	3	3
3	EDITOR	4	4	4	4	3	4	3
4	MANAGER	5	5	5	5	5	5	5
\.


--
-- Data for Name: jcm_user; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_user (id, mail_address, salt, password, username, token, ts_access, fk_user_role) FROM stdin;
1	anonymous@amiesca.com	anonymous	anonymous	anonymous	\N	2019-09-01 08:13:16.992999	1
\.


--
-- Data for Name: jcm_cotation; Type: TABLE DATA; Schema: public; Owner: amiesca
--

COPY public.jcm_cotation (id, label) FROM stdin;
1	1
2	2
3	3
4	4
5	5a
6	5b
7	5c
8	6a
9	6a+
10	6b
11	6b+
12	6c
13	6c+
14	7a
15	7a+
16	7b
17	7b+
18	7c
19	7c+
20	8a
21	8a+
22	8b
23	8b+
24	8c
25	8c+
26	9a
27	9a+
28	9b
29	9b+
30	9c
\.


--
-- Name: jcm_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amiesca
--

SELECT pg_catalog.setval('public.jcm_user_id_seq', 1, true);


--
-- PostgreSQL database dump complete
--

