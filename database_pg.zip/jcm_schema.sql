--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7 (Ubuntu 10.7-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 11.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: jcm_access_type; Type: TABLE; Schema: public; Owner: amiesca
--

CREATE TABLE public.jcm_access_type (
    id integer NOT NULL,
    name character varying NOT NULL,
    description character varying
);


--
-- Name: jcm_comment; Type: TABLE; Schema: public; Owner: amiesca
--

CREATE TABLE public.jcm_comment (
    id integer NOT NULL,
    ts_created timestamp without time zone DEFAULT now() NOT NULL,
    ts_modified timestamp without time zone DEFAULT now() NOT NULL,
    content character varying DEFAULT ''::character varying,
    fk_comment_reference integer NOT NULL,
    fk_comment_user integer NOT NULL
);


--
-- Name: jcm_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: amiesca
--

CREATE SEQUENCE public.jcm_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jcm_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amiesca
--

ALTER SEQUENCE public.jcm_comment_id_seq OWNED BY public.jcm_comment.id;


--
-- Name: jcm_cotation; Type: TABLE; Schema: public; Owner: amiesca
--

CREATE TABLE public.jcm_cotation (
    id integer NOT NULL,
    label character varying NOT NULL
);


--
-- Name: jcm_message; Type: TABLE; Schema: public; Owner: amiesca
--

CREATE TABLE public.jcm_message (
    id integer NOT NULL,
    fk_sender_user integer NOT NULL,
    fk_receiver_user integer NOT NULL,
    title character varying DEFAULT ''::character varying,
    content character varying DEFAULT ''::character varying,
    dt_created timestamp without time zone DEFAULT now(),
    dt_read timestamp without time zone,
    parent_id integer,
    discussion_id integer DEFAULT 0,
    discussion_masked integer DEFAULT 0,
    last_discussion_message boolean DEFAULT false
);


--
-- Name: jcm_message_id_seq; Type: SEQUENCE; Schema: public; Owner: amiesca
--

CREATE SEQUENCE public.jcm_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jcm_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amiesca
--

ALTER SEQUENCE public.jcm_message_id_seq OWNED BY public.jcm_message.id;


--
-- Name: jcm_reference; Type: TABLE; Schema: public; Owner: amiesca
--

CREATE TABLE public.jcm_reference (
    id integer NOT NULL,
    name character varying NOT NULL,
    type character varying,
    summary character varying DEFAULT ''::character varying,
    slug character varying NOT NULL,
    fk_document_user integer DEFAULT 1 NOT NULL,
    ts_created timestamp without time zone DEFAULT now() NOT NULL,
    ts_modified timestamp without time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT true NOT NULL,
    content character varying DEFAULT ''::character varying
);


--
-- Name: jcm_reference_id_seq; Type: SEQUENCE; Schema: public; Owner: amiesca
--

CREATE SEQUENCE public.jcm_reference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jcm_reference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amiesca
--

ALTER SEQUENCE public.jcm_reference_id_seq OWNED BY public.jcm_reference.id;


--
-- Name: jcm_role; Type: TABLE; Schema: public; Owner: amiesca
--

CREATE TABLE public.jcm_role (
    id integer NOT NULL,
    name character varying DEFAULT 2 NOT NULL,
    fk_site_access integer NOT NULL,
    fk_topo_access integer NOT NULL,
    fk_comment_access integer NOT NULL,
    fk_media_access integer NOT NULL,
    fk_user_access integer NOT NULL,
    fk_booking_access integer NOT NULL,
    fk_message_access integer NOT NULL
);


--
-- Name: jcm_site; Type: TABLE; Schema: public; Owner: amiesca
--

CREATE TABLE public.jcm_site (
    pfk_site_reference integer NOT NULL,
    country character varying NOT NULL,
    department character varying NOT NULL,
    cliff boolean DEFAULT true NOT NULL,
    block boolean DEFAULT true NOT NULL,
    wall boolean DEFAULT false NOT NULL,
    paths_number integer DEFAULT 0 NOT NULL,
    min_height integer DEFAULT 0 NOT NULL,
    max_height integer DEFAULT 0 NOT NULL,
    fk_min_site_cotation integer DEFAULT 1 NOT NULL,
    fk_max_site_cotation integer DEFAULT 1 NOT NULL,
    orientation character varying DEFAULT ''::character varying,
    friend_tag boolean DEFAULT false NOT NULL
);


--
-- Name: jcm_topo; Type: TABLE; Schema: public; Owner: amiesca
--

CREATE TABLE public.jcm_topo (
    pfk_topo_reference integer NOT NULL,
    title character varying NOT NULL,
    writer character varying DEFAULT ''::character varying,
    writed_at character varying DEFAULT ''::character varying,
    published boolean DEFAULT true NOT NULL,
    available boolean DEFAULT true
);


--
-- Name: jcm_topo_site; Type: TABLE; Schema: public; Owner: amiesca
--

CREATE TABLE public.jcm_topo_site (
    pfk_topo integer NOT NULL,
    pfk_site integer NOT NULL
);


--
-- Name: jcm_user; Type: TABLE; Schema: public; Owner: amiesca
--

CREATE TABLE public.jcm_user (
    id integer NOT NULL,
    mail_address character varying NOT NULL,
    salt character varying NOT NULL,
    password character varying NOT NULL,
    username character varying NOT NULL,
    token character varying,
    ts_access timestamp without time zone DEFAULT now() NOT NULL,
    fk_user_role integer DEFAULT 1 NOT NULL
);


--
-- Name: jcm_user_id_seq; Type: SEQUENCE; Schema: public; Owner: amiesca
--

CREATE SEQUENCE public.jcm_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jcm_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amiesca
--

ALTER SEQUENCE public.jcm_user_id_seq OWNED BY public.jcm_user.id;


--
-- Name: jcm_comment id; Type: DEFAULT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_comment ALTER COLUMN id SET DEFAULT nextval('public.jcm_comment_id_seq'::regclass);


--
-- Name: jcm_message id; Type: DEFAULT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_message ALTER COLUMN id SET DEFAULT nextval('public.jcm_message_id_seq'::regclass);


--
-- Name: jcm_reference id; Type: DEFAULT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_reference ALTER COLUMN id SET DEFAULT nextval('public.jcm_reference_id_seq'::regclass);


--
-- Name: jcm_user id; Type: DEFAULT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_user ALTER COLUMN id SET DEFAULT nextval('public.jcm_user_id_seq'::regclass);


--
-- Name: jcm_access_type jcm_access_type_pk; Type: CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_access_type
    ADD CONSTRAINT jcm_access_type_pk PRIMARY KEY (id);


--
-- Name: jcm_comment jcm_comment_pk; Type: CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_comment
    ADD CONSTRAINT jcm_comment_pk PRIMARY KEY (id);


--
-- Name: jcm_cotation jcm_cotation_pk; Type: CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_cotation
    ADD CONSTRAINT jcm_cotation_pk PRIMARY KEY (id);


--
-- Name: jcm_message jcm_message_pk; Type: CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_message
    ADD CONSTRAINT jcm_message_pk PRIMARY KEY (id);


--
-- Name: jcm_reference jcm_reference_pk; Type: CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_reference
    ADD CONSTRAINT jcm_reference_pk PRIMARY KEY (id);


--
-- Name: jcm_role jcm_role_pk; Type: CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_role
    ADD CONSTRAINT jcm_role_pk PRIMARY KEY (id);


--
-- Name: jcm_site jcm_site_pk; Type: CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_site
    ADD CONSTRAINT jcm_site_pk PRIMARY KEY (pfk_site_reference);


--
-- Name: jcm_topo jcm_topo_pk; Type: CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_topo
    ADD CONSTRAINT jcm_topo_pk PRIMARY KEY (pfk_topo_reference);


--
-- Name: jcm_topo_site jcm_topo_site_pk; Type: CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_topo_site
    ADD CONSTRAINT jcm_topo_site_pk PRIMARY KEY (pfk_topo, pfk_site);


--
-- Name: jcm_user jcm_user_pk; Type: CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_user
    ADD CONSTRAINT jcm_user_pk PRIMARY KEY (id);


--
-- Name: jcm_site cotation_enum_jcm_card_fk; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_site
    ADD CONSTRAINT cotation_enum_jcm_card_fk FOREIGN KEY (fk_min_site_cotation) REFERENCES public.jcm_cotation(id) ON DELETE SET DEFAULT;


--
-- Name: jcm_site cotation_enum_jcm_card_fk1; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_site
    ADD CONSTRAINT cotation_enum_jcm_card_fk1 FOREIGN KEY (fk_max_site_cotation) REFERENCES public.jcm_cotation(id) ON DELETE SET DEFAULT;


--
-- Name: jcm_role jcm_access_type_jcm_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_role
    ADD CONSTRAINT jcm_access_type_jcm_role_fk FOREIGN KEY (fk_site_access) REFERENCES public.jcm_access_type(id);


--
-- Name: jcm_role jcm_access_type_jcm_role_fk1; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_role
    ADD CONSTRAINT jcm_access_type_jcm_role_fk1 FOREIGN KEY (fk_topo_access) REFERENCES public.jcm_access_type(id);


--
-- Name: jcm_role jcm_access_type_jcm_role_fk2; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_role
    ADD CONSTRAINT jcm_access_type_jcm_role_fk2 FOREIGN KEY (fk_comment_access) REFERENCES public.jcm_access_type(id);


--
-- Name: jcm_role jcm_access_type_jcm_role_fk3; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_role
    ADD CONSTRAINT jcm_access_type_jcm_role_fk3 FOREIGN KEY (fk_media_access) REFERENCES public.jcm_access_type(id);


--
-- Name: jcm_role jcm_access_type_jcm_role_fk4; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_role
    ADD CONSTRAINT jcm_access_type_jcm_role_fk4 FOREIGN KEY (fk_user_access) REFERENCES public.jcm_access_type(id);


--
-- Name: jcm_role jcm_access_type_jcm_role_fk5; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_role
    ADD CONSTRAINT jcm_access_type_jcm_role_fk5 FOREIGN KEY (fk_booking_access) REFERENCES public.jcm_access_type(id);


--
-- Name: jcm_role jcm_access_type_jcm_role_fk6; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_role
    ADD CONSTRAINT jcm_access_type_jcm_role_fk6 FOREIGN KEY (fk_message_access) REFERENCES public.jcm_access_type(id);


--
-- Name: jcm_site jcm_document_jcm_card_fk; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_site
    ADD CONSTRAINT jcm_document_jcm_card_fk FOREIGN KEY (pfk_site_reference) REFERENCES public.jcm_reference(id);


--
-- Name: jcm_topo jcm_document_jcm_topo_fk; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_topo
    ADD CONSTRAINT jcm_document_jcm_topo_fk FOREIGN KEY (pfk_topo_reference) REFERENCES public.jcm_reference(id);


--
-- Name: jcm_message jcm_message_jcm_message_fk; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_message
    ADD CONSTRAINT jcm_message_jcm_message_fk FOREIGN KEY (parent_id) REFERENCES public.jcm_message(id);


--
-- Name: jcm_comment jcm_reference_jcm_comment_fk; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_comment
    ADD CONSTRAINT jcm_reference_jcm_comment_fk FOREIGN KEY (fk_comment_reference) REFERENCES public.jcm_reference(id);


--
-- Name: jcm_user jcm_role_jcm_user_fk1; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_user
    ADD CONSTRAINT jcm_role_jcm_user_fk1 FOREIGN KEY (fk_user_role) REFERENCES public.jcm_role(id);


--
-- Name: jcm_topo_site jcm_site_jcm_topo_site_fk; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_topo_site
    ADD CONSTRAINT jcm_site_jcm_topo_site_fk FOREIGN KEY (pfk_site) REFERENCES public.jcm_site(pfk_site_reference);


--
-- Name: jcm_topo_site jcm_topo_jcm_topo_site_fk; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_topo_site
    ADD CONSTRAINT jcm_topo_jcm_topo_site_fk FOREIGN KEY (pfk_topo) REFERENCES public.jcm_topo(pfk_topo_reference);


--
-- Name: jcm_comment jcm_user_jcm_comment_fk1; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_comment
    ADD CONSTRAINT jcm_user_jcm_comment_fk1 FOREIGN KEY (fk_comment_user) REFERENCES public.jcm_user(id);


--
-- Name: jcm_reference jcm_user_jcm_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_reference
    ADD CONSTRAINT jcm_user_jcm_document_fk FOREIGN KEY (fk_document_user) REFERENCES public.jcm_user(id);


--
-- Name: jcm_message jcm_user_jcm_message_fk; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_message
    ADD CONSTRAINT jcm_user_jcm_message_fk FOREIGN KEY (fk_sender_user) REFERENCES public.jcm_user(id);


--
-- Name: jcm_message jcm_user_jcm_message_fk1; Type: FK CONSTRAINT; Schema: public; Owner: amiesca
--

ALTER TABLE ONLY public.jcm_message
    ADD CONSTRAINT jcm_user_jcm_message_fk1 FOREIGN KEY (fk_receiver_user) REFERENCES public.jcm_user(id);


--
-- PostgreSQL database dump complete
--

